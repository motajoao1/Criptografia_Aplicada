#!/usr/bin/env bash
# Verifica um documento em duas etapas independentes e emite uma decisão.
# Uso: ./verificar.sh <documento> <assinatura.sig> <certificado_signatario.crt> <ancora_confiavel.crt>
DOC="$1"; SIG="$2"; CERT="$3"; TRUST="$4"
PUB=$(mktemp)
openssl x509 -in "$CERT" -pubkey -noout > "$PUB"

echo "  Documento: $DOC"
echo "  SHA-256:   $(openssl dgst -sha256 -r "$DOC" | cut -d' ' -f1)"
echo "  Signatário (subject): $(openssl x509 -in "$CERT" -noout -subject | sed 's/subject=//')"
echo "  Emissor   (issuer):   $(openssl x509 -in "$CERT" -noout -issuer  | sed 's/issuer=//')"

echo "  [1] Verificação criptográfica da assinatura (RSA-PSS/SHA-256):"
if openssl dgst -sha256 -verify "$PUB" -sigopt rsa_padding_mode:pss -sigopt rsa_pss_saltlen:-1 \
     -signature "$SIG" "$DOC" 2>&1 | sed 's/^/      /'; then ASSIN=OK; else ASSIN=FALHA; fi
# (o sed acima mascara o código de retorno; refaz o teste silenciosamente)
openssl dgst -sha256 -verify "$PUB" -sigopt rsa_padding_mode:pss -sigopt rsa_pss_saltlen:-1 \
     -signature "$SIG" "$DOC" >/dev/null 2>&1 && ASSIN=OK || ASSIN=FALHA

echo "  [2] Validação da cadeia contra a âncora de confiança ($TRUST):"
openssl verify -x509_strict -CAfile "$TRUST" -show_chain "$CERT" 2>&1 | sed 's/^/      /'
openssl verify -x509_strict -CAfile "$TRUST" "$CERT" >/dev/null 2>&1 && CADEIA=OK || CADEIA=FALHA

if [[ $ASSIN == OK && $CADEIA == OK ]]; then DEC="ACEITAR"; else DEC="REJEITAR"; fi
echo "  >> Assinatura: $ASSIN | Cadeia: $CADEIA | DECISÃO: $DEC"
rm -f "$PUB"
