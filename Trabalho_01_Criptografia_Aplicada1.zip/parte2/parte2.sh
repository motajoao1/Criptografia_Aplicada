#!/usr/bin/env bash
# Parte II - Assinaturas digitais e certificados (OpenSSL 3.x)
# Gera a PKI de teste, produz os casos A, B e C e verifica cada um.
# Uso: bash parte2.sh   (precisa estar na mesma pasta do verificar.sh)
set -euo pipefail
cd "$(dirname "$0")"

#DOC_ORIGINAL é para trocar rapidamente o nome e caminho do arquivo testado para esse laboratório, taokei
DOC_ORIGINAL="../parte1/doc_teste.txt"
SUBJ_SIGNATARIO="/C=BR/O=CUFBA/OU=Financeiro/CN=Compras"

# Retorno de erro se n achar o arquivo
[[ -f "$DOC_ORIGINAL" ]] || { echo "ERRO: não encontrei $DOC_ORIGINAL"; exit 1; }
[[ -f verificar.sh ]]    || { echo "ERRO: não encontrei verificar.sh nesta pasta"; exit 1; }

rm -rf pki casos; mkdir -p pki casos/A casos/B casos/C

#Cria o arquivo cnf q é o arquivo de configuração do certificado
cat > pki/ext_signatario.cnf << 'X'
basicConstraints=critical,CA:FALSE
keyUsage=critical,digitalSignature,nonRepudiation
subjectKeyIdentifier=hash
authorityKeyIdentifier=keyid
X
#Cria o certificado autoassinável sem senha (sem senha pq é laboratório)
echo "== 1. PKI legítima: CA raiz (âncora de confiança) =="
openssl req -x509 -newkey rsa:3072 -nodes -sha256 -days 3650 \
  -keyout pki/ca_confiavel.key -out pki/ca_confiavel.crt \
  -subj "/C=BR/O=CUFBA/CN=CUFBA Root CA" \
  -addext "basicConstraints=critical,CA:TRUE" \
  -addext "keyUsage=critical,keyCertSign,cRLSign" 2>/dev/null

echo "== 2. Signatário legítimo, certificado emitido pela CA confiável =="
openssl req -newkey rsa:3072 -nodes -keyout pki/signatario.key \
  -out pki/signatario.csr -subj "$SUBJ_SIGNATARIO" 2>/dev/null
openssl x509 -req -sha256 -days 365 -in pki/signatario.csr \
  -CA pki/ca_confiavel.crt -CAkey pki/ca_confiavel.key -CAcreateserial \
  -extfile pki/ext_signatario.cnf -out pki/signatario.crt 2>/dev/null

echo "== 3. PKI do atacante: CA NÃO confiável + certificado com o MESMO nome do signatário =="
openssl req -x509 -newkey rsa:3072 -nodes -sha256 -days 3650 \
  -keyout pki/ca_nao_confiavel.key -out pki/ca_nao_confiavel.crt \
  -subj "/C=BR/O=Certificadora GenericAll/CN=TestyCall" \
  -addext "basicConstraints=critical,CA:TRUE" \
  -addext "keyUsage=critical,keyCertSign,cRLSign" 2>/dev/null
openssl req -newkey rsa:3072 -nodes -keyout pki/impostor.key \
  -out pki/impostor.csr -subj "$SUBJ_SIGNATARIO" 2>/dev/null
openssl x509 -req -sha256 -days 365 -in pki/impostor.csr \
  -CA pki/ca_nao_confiavel.crt -CAkey pki/ca_nao_confiavel.key -CAcreateserial \
  -extfile pki/ext_signatario.cnf -out pki/impostor.crt 2>/dev/null

# Assinar
assinar() {
  openssl dgst -sha256 -sign "$1" \
    -sigopt rsa_padding_mode:pss -sigopt rsa_pss_saltlen:-1 \
    -out "$3" "$2"
}

echo "== 4. Montagem dos casos =="
# Caso A
cp "$DOC_ORIGINAL" casos/A/documento.txt
assinar pki/signatario.key casos/A/documento.txt casos/A/documento.sig
cp pki/signatario.crt casos/A/

# Caso B
cp casos/A/documento.sig casos/A/signatario.crt casos/B/
sed -e 's/R\$ 15,00/R\$ 1,00/' casos/A/documento.txt > casos/B/documento.txt
cmp -s casos/A/documento.txt casos/B/documento.txt && { echo "ERRO: o caso B ficou idêntico ao A; ajuste o sed"; exit 1; }
echo "   Diferença introduzida no caso B:"
diff casos/A/documento.txt casos/B/documento.txt | sed 's/^/     /' || true

# Caso C
cp casos/B/documento.txt casos/C/documento.txt
assinar pki/impostor.key casos/C/documento.txt casos/C/documento.sig
cp pki/impostor.crt casos/C/signatario.crt

echo; echo "== CASO A: original + assinatura correta + CA confiável =="
bash verificar.sh casos/A/documento.txt casos/A/documento.sig casos/A/signatario.crt pki/ca_confiavel.crt
echo; echo "== CASO B: documento alterado após a assinatura =="
bash verificar.sh casos/B/documento.txt casos/B/documento.sig casos/B/signatario.crt pki/ca_confiavel.crt
echo; echo "== CASO C: assinatura válida, certificado de CA não confiável =="
bash verificar.sh casos/C/documento.txt casos/C/documento.sig casos/C/signatario.crt pki/ca_confiavel.crt

echo; echo "== Evidência complementar do caso C =="
echo "-- Certificado do impostor validado contra a CA do próprio atacante (é bem formado):"
openssl verify -CAfile pki/ca_nao_confiavel.crt pki/impostor.crt
echo "-- Mesmo subject, chaves públicas diferentes (SHA-256 da chave pública):"
for c in pki/signatario.crt pki/impostor.crt; do
  printf "   %-20s %s\n" "$c" "$(openssl x509 -in "$c" -pubkey -noout | openssl pkey -pubin -outform DER | openssl dgst -sha256 -r | cut -d' ' -f1)"
done
echo "-- Fingerprints SHA-256 dos certificados:"
for c in pki/ca_confiavel.crt pki/ca_nao_confiavel.crt pki/signatario.crt pki/impostor.crt; do
  printf "   %-24s %s\n" "$c" "$(openssl x509 -in "$c" -noout -fingerprint -sha256 | cut -d= -f2)"
done