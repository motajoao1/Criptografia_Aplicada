"""
Parte I - Proteção e integridade de documentos
1 Criar um documento comercial fictício em .txt.
2 Criptografá-lo utilizando AES-GCM, por meio de uma biblioteca criptográfica.
3 Demonstrar a descriptografia com a chave correta.
4 Testar o comportamento da descriptografia após alterar o conteúdo criptografado ou utilizar uma chave incorreta.
5 Explicar quais propriedades de segurança foram garantidas.

Biblioteca usada: pyca/cryptography (https://cryptography.io)

Uso no terminal: python aes_gcm_demo.py doc_teste.txt
"""
import os, sys, hashlib
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.exceptions import InvalidTag

def sha256(b): return hashlib.sha256(b).hexdigest()

def tentar_decifrar(titulo, chave, nonce, ct, aad):
    print(f"\n[{titulo}]")
    try:
        pt = AESGCM(chave).decrypt(nonce, ct, aad)
        print(f"  RESULTADO: sucesso | SHA-256 = {sha256(pt)}")
        return pt
    except InvalidTag:
        print("  RESULTADO: InvalidTag -> decifração recusada")
        return None

arquivo = sys.argv[1] if len(sys.argv) > 1 else "doc_teste.txt"
texto = open(arquivo, "rb").read()
print(f"Documento original: {arquivo} ({len(texto)} bytes)")
print(f"SHA-256 original: {sha256(texto)}")

# 1) Geração de chave (256 bits) e nonce (96 bits)
chave = AESGCM.generate_key(bit_length=256)
nonce = os.urandom(12)
# AAD
aad = b"XYZW-Doc_Teste-v1"

# 2) Cifragem: saída = texto cifrado || tag de 16 bytes
ct = AESGCM(chave).encrypt(nonce, texto, aad)
open("doc_teste.enc", "wb").write(nonce + ct)   # formato: nonce(12) || ct, onde ct = dados cifrados + tag(16)
open("chave_TESTE.bin", "wb").write(chave)  # É a chave. Deixei aqui unicamente por ser ATIV LAB.
print(f"\nChave (hex):  {chave.hex()}")
print(f"Nonce (hex):  {nonce.hex()}")
print(f"AAD:          {aad.decode()}")
print(f"Cifrado: {len(ct)} bytes = {len(texto)} de dados + 16 de tag")
print(f"Primeiros 32 bytes do cifrado: {ct[:32].hex()}")
print(f"Tag GCM: {ct[-16:].hex()}")

# Teste de mesma mensagem criptografada com mesma chave mas nonce novo
ct2 = AESGCM(chave).encrypt(os.urandom(12), texto, aad)
print(f"Recifrando com outro nonce, 32 primeiros bytes: {ct2[:32].hex()}")
# Obs: Não salvei o nonce novo, então não vai dar para descriptografar. Coloquei aqui apenas para visualizar que dá um resultado diferente com nonce diferente.

# 3) Decifrar com a chave correta
pt = tentar_decifrar("T1 - chave correta", chave, nonce, ct, aad)
print("  Idêntico ao original?", pt == texto)

# 4) Testes de violação
adulterado = bytearray(ct); adulterado[60] ^= 0x01         # inverte 1 bit no corpo cifrado
tentar_decifrar("T2 - 1 bit alterado no texto cifrado", chave, nonce, bytes(adulterado), aad)

tag_alt = bytearray(ct); tag_alt[-1] ^= 0x01               # inverte 1 bit na tag
tentar_decifrar("T3 - 1 bit alterado na tag", chave, nonce, bytes(tag_alt), aad)

tentar_decifrar("T4 - chave incorreta", AESGCM.generate_key(bit_length=256), nonce, ct, aad)

tentar_decifrar("T5 - AAD alterado (v1 -> v2)", chave, nonce, ct, b"XYZW-Doc_Teste-v2")

tentar_decifrar("T6 - nonce incorreto", chave, os.urandom(12), ct, aad)

tentar_decifrar("T7 - truncamento (último bloco removido)", chave, nonce, ct[:-32] + ct[-16:], aad)
